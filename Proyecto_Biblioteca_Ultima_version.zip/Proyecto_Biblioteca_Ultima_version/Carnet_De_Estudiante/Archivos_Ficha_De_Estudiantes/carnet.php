<?php
require_once __DIR__ . '/../../Inicio_Sesion/sesion.php';
$raiz = '../../';
exigir_sesion($raiz);

$id = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) : (int)$_SESSION['id'];
$botones = es_admin()
    ? [['Volver a la tabla de usuarios', $raiz . 'tabla_usuarios/pagina_tabla_usuarios.php'], ['Volver a la página principal', url_principal($raiz)]]
    : [['Ir a mi carnet', url_carnet($raiz)], ['Volver a la página principal', url_principal($raiz)]];
if (!$id) {
    mostrar_error($raiz, 'Carnet no válido', 'El carnet que intentás abrir no es válido.', $botones, 400);
}
if (!es_admin() && (int)$id !== (int)$_SESSION['id']) {
    mostrar_error($raiz, 'Acceso restringido', 'Solo podés consultar tu propio carnet.', $botones, 403);
}

if ((int)$id === (int)$_SESSION['id']) {
    header('Location: ' . url_carnet($raiz));
    exit;
}

$cursos = [];
foreach (range(1, 6) as $anio) {
    foreach (['A', 'B', 'C', 'D'] as $division) {
        $cursos[] = $anio . '°' . $division;
    }
}
if (empty($_SESSION['carnet_csrf'])) {
    $_SESSION['carnet_csrf'] = bin2hex(random_bytes(32));
}
$error = '';
try {
    require_once __DIR__ . '/conexion.php';
    $stmt = $conexion->prepare('SELECT id, usuario, tel, mail, sans, curso_actual, rango FROM usuarios WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $alumno = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$alumno) {
        mostrar_error($raiz, 'Usuario no encontrado', 'No existe ningún usuario con ese ID.', $botones, 404);
    }

    $esAlumno = strcasecmp(trim((string)$alumno['rango']), 'Alumno') === 0;
    $puedeEditarCurso = es_admin() && $esAlumno;
    $puedeQuitarSancion = strcasecmp(trim((string)($_SESSION['rango'] ?? '')), 'Directivo') === 0;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $accion = $_POST['accion'] ?? '';
        $token = $_POST['csrf'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['carnet_csrf'], $token)) {
            $error = 'La solicitud venció. Actualizá la página e intentá de nuevo.';
        } elseif ($accion === 'modificar_curso' && $puedeEditarCurso) {
            $nuevoCurso = $_POST['cam_curso'] ?? '';
            if (!is_string($nuevoCurso) || !in_array($nuevoCurso, $cursos, true)) {
                $error = 'Seleccioná un curso válido.';
            } else {
                $actualizar = $conexion->prepare("UPDATE usuarios SET curso_actual = ? WHERE id = ? AND LOWER(TRIM(rango)) = 'alumno'");
                $actualizar->bind_param('si', $nuevoCurso, $id);
                $actualizar->execute();
                $modificados = $actualizar->affected_rows;
                $actualizar->close();
                if ($modificados === 0 && $nuevoCurso !== $alumno['curso_actual']) {
                    $error = 'No se actualizó el curso: el usuario cambió de rango o ya no está disponible. Recargá el carnet.';
                } else {
                    header('Location: carnet.php?id=' . $id);
                    exit;
                }
            }
        } elseif ($accion === 'quitar_sancion' && $puedeQuitarSancion) {
            $motivo = $_POST['motivo'] ?? null;
            if (!is_string($motivo) || $motivo === '' || (function_exists('mb_strlen') ? mb_strlen($motivo, 'UTF-8') : strlen($motivo)) > 999) {
                $error = 'La sanción indicada no es válida.';
            } else {
                $quitar = $conexion->prepare('DELETE FROM sansl WHERE id = ? AND sans1 = ? LIMIT 1');
                $quitar->bind_param('is', $id, $motivo);
                $quitar->execute();
                $eliminadas = $quitar->affected_rows;
                $quitar->close();
                if ($eliminadas === 0) {
                    $error = 'La sanción ya no está registrada. Recargá el carnet para ver la lista actual.';
                } else {
                    header('Location: carnet.php?id=' . $id . '#sanciones');
                    exit;
                }
            }
        } else {
            http_response_code(403);
            $error = 'No tenés permiso para realizar esta acción.';
        }
    }

    $stmt = $conexion->prepare('SELECT sans1 FROM sansl WHERE id = ? ORDER BY id');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $sanciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $conexion->close();
} catch (Throwable $e) {
    mostrar_error($raiz, 'Error de conexión', 'No se pudo cargar el carnet. Intentá nuevamente.', $botones, 500);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carnet de <?= h($alumno['usuario']) ?> | Biblioteca Común</title>
    <link rel="stylesheet" href="styles.css?v=<?= (int)filemtime(__DIR__ . '/styles.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
<header>
    <a class="marca" href="<?= h(url_carnet($raiz)) ?>">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5.5C4 4.7 4.7 4 5.5 4H11v15H5.5C4.7 19 4 18.3 4 17.5v-12z"/><path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H13v15h5.5c.8 0 1.5-.7 1.5-1.5v-12z"/></svg>
        <span>Biblioteca Virtual</span>
    </a>
        <span class="contexto-header" aria-label="Sección actual">Carnet de usuario</span>
    <?php mostrar_sesion($raiz); ?>
</header>
<div class="sub-header"><span>Biblioteca Virtual</span><span class="separador">•</span><strong>Villa Gardel</strong></div>
<main>
    <section class="recuadro_al_centro">
        <div class="carnet">
            <div class="titulo_carnet"><h1>CARNET DEL USUARIO</h1></div>
            <?php if ($error !== ''): ?><p class="aviso-carnet" role="alert"><?= h($error) ?></p><?php endif; ?>
            <div class="contenido_carnet">
                <div class="datos_estudiante">
                    <div class="dato"><span class="etiqueta">NOMBRE</span><strong><?= h($alumno['usuario']) ?></strong></div>
                    <div class="dato"><span class="etiqueta">ID</span><strong><?= h($alumno['id']) ?></strong></div>
                    <div class="dato"><span class="etiqueta">MAIL</span><strong><?= h($alumno['mail']) ?></strong></div>
                    <div class="dato"><span class="etiqueta">Teléfono</span><strong><?= h($alumno['tel']) ?></strong></div>
                    <div class="dato <?= $esAlumno ? '' : 'dato-ancho' ?>"><span class="etiqueta">Rango en el sistema</span><strong><?= h($alumno['rango']) ?></strong></div>
                    <?php if ($esAlumno): ?>
                    <div class="dato">
                        <span class="etiqueta">Curso</span><strong><?= h($alumno['curso_actual']) ?></strong>
                        <?php if ($puedeEditarCurso): ?>
                        <form method="post" class="formulario-curso">
                            <input type="hidden" name="accion" value="modificar_curso">
                            <input type="hidden" name="csrf" value="<?= h($_SESSION['carnet_csrf']) ?>">
                            <label for="cam_curso">Cambiar curso</label>
                            <select id="cam_curso" name="cam_curso" required>
                                <option value="" disabled selected>Seleccioná un curso</option>
                                <?php foreach ($cursos as $curso): ?><option value="<?= h($curso) ?>"><?= h($curso) ?></option><?php endforeach; ?>
                            </select>
                            <button type="submit" class="añadir">Guardar curso</button>
                        </form>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="titulo_seccion" id="sanciones">
                <h2>SANCIONES</h2>
                <?php if (es_admin()): ?>
                <a href="../../formulario_añadir/Agregar_sancion.php?id=<?= (int)$id ?>" class="hero-boton">Añadir sanción</a>
                <?php endif; ?>
            </div>
            <div class="lista_sanciones">
                <?php if (!$sanciones): ?>
                <div class="sancion sin_sanciones"><div class="icono_sancion">✓</div><div><h3>Sin sanciones activas</h3><p>Este usuario no posee sanciones actualmente.</p></div></div>
                <?php else: foreach ($sanciones as $sancion): ?>
                <div class="sancion sancion-activa">
                    <div class="icono_sancion">!</div>
                    <div class="detalle-sancion"><h3>Sanción</h3><p><?= h($sancion['sans1']) ?></p></div>
                    <?php if ($puedeQuitarSancion): ?>
                    <form method="post" class="formulario-quitar">
                        <input type="hidden" name="accion" value="quitar_sancion">
                        <input type="hidden" name="csrf" value="<?= h($_SESSION['carnet_csrf']) ?>">
                        <input type="hidden" name="motivo" value="<?= h($sancion['sans1']) ?>">
                        <button type="submit" class="boton-quitar">Quitar sanción</button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </section>
</main>
<?php if ($puedeQuitarSancion && $sanciones): ?>
<dialog class="confirmacion-sancion" id="confirmacion-sancion" aria-labelledby="titulo-confirmacion" aria-describedby="mensaje-confirmacion">
    <div class="confirmacion-panel">
        <span class="confirmacion-icono" aria-hidden="true">!</span>
        <p class="confirmacion-etiqueta">Confirmar cambio</p>
        <h2 id="titulo-confirmacion">¿Quitar esta sanción?</h2>
        <p id="mensaje-confirmacion">¿Seguro que querés eliminar la sanción <strong id="motivo-confirmacion"></strong> de <strong><?= h($alumno['usuario']) ?></strong>?</p>
        <div class="confirmacion-acciones">
            <button type="button" class="confirmacion-cancelar" id="cancelar-confirmacion">Cancelar</button>
            <button type="button" class="confirmacion-aceptar" id="confirmar-quitar">Sí, quitar sanción</button>
        </div>
    </div>
</dialog>
<?php endif; ?>
<footer><div class="parte_de_abajo"><span>Todos los derechos reservados — Grupo Medusa</span></div></footer>
<script>
const confirmacion = document.getElementById('confirmacion-sancion');
if (confirmacion) {
    let formularioPendiente = null;
    const nombreUsuario = <?= json_encode($alumno['usuario'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
    document.querySelectorAll('.formulario-quitar').forEach(formulario => {
        formulario.addEventListener('submit', evento => {
            if (formulario.dataset.confirmada === 'si') return;
            evento.preventDefault();
            const motivo = formulario.querySelector('[name="motivo"]').value;
            if (typeof confirmacion.showModal !== 'function') {
                if (window.confirm('¿Seguro que querés eliminar la sanción ' + motivo + ' de ' + nombreUsuario + '?')) {
                    formulario.dataset.confirmada = 'si';
                    formulario.requestSubmit();
                }
                return;
            }
            formularioPendiente = formulario;
            document.getElementById('motivo-confirmacion').textContent = motivo;
            confirmacion.showModal();
            document.getElementById('cancelar-confirmacion').focus();
        });
    });
    document.getElementById('cancelar-confirmacion').addEventListener('click', () => confirmacion.close());
    document.getElementById('confirmar-quitar').addEventListener('click', () => {
        if (!formularioPendiente) return;
        const formulario = formularioPendiente;
        formularioPendiente = null;
        confirmacion.close();
        formulario.dataset.confirmada = 'si';
        formulario.requestSubmit();
    });
    confirmacion.addEventListener('close', () => { formularioPendiente = null; });
    confirmacion.addEventListener('click', evento => {
        if (evento.target === confirmacion) confirmacion.close();
    });
}
</script>
</body>
</html>
