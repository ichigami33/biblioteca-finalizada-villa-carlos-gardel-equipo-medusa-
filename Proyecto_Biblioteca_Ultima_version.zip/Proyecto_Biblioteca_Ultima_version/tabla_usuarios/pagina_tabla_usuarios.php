<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);

header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

$host = 'localhost';
$dbname = 'bibloteca';
$usuario = 'root';
$password = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $usuario,
        $password
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    mostrar_error(
        $raiz,
        'Error de conexión',
        'No se pudo conectar con la base de datos. Verificá que el servidor esté encendido e intentá nuevamente.',
        [
            ['Volver a intentar', 'pagina_tabla_usuarios.php'],
            ['Volver a la página principal', url_principal($raiz)]
        ],
        500
    );
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de usuarios | Biblioteca Común</title>
    <link rel="stylesheet" href="styles.css?v=<?= (int)filemtime(__DIR__ . '/styles.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
<header id="header">
    <a class="marca" href="<?= h(url_principal($raiz)) ?>">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round"
             aria-hidden="true">
            <path d="M4 5.5C4 4.7 4.7 4 5.5 4H11v15H5.5C4.7 19 4 18.3 4 17.5v-12z"/>
            <path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H13v15h5.5c.8 0 1.5-.7 1.5-1.5v-12z"/>
        </svg>
        <span>Biblioteca Virtual</span>
    </a>
        <span class="contexto-header" aria-label="Sección actual">Usuarios</span>
    <?php mostrar_sesion($raiz); ?>
</header>

<section class="hero">
    <img class="hero-imagen" src="books-5211309_1280.jpg" alt="Biblioteca">
    <div class="hero-info">
        <h2>Tabla de usuarios</h2>
        <p>Desde esta sección podés consultar los usuarios registrados en la Biblioteca Común.</p>
        <p class="hero-dato">Seleccioná el nombre de un usuario para acceder a su carnet.</p>
        <a href="#alumnos" class="hero-boton">Ver usuarios</a>
    </div>
</section>

<main class="catalogo" id="alumnos">
    <div class="catalogo-cabecera">
        <h1 id="titulo">Usuarios registrados</h1>
        <p class="catalogo-intro">
            Estos son los usuarios registrados en el sistema.
            Seleccioná un nombre para consultar su información.
        </p>
    </div>

    <div class="zona-filtros">
        <div class="buscador-usuarios" role="search">
            <svg class="buscador-icono" width="22" height="22"
                 viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 aria-hidden="true">
                <circle cx="11" cy="11" r="6.5"/>
                <path d="M16 16l4.5 4.5"/>
            </svg>

            <input
                type="search"
                id="busqueda"
                placeholder="Buscá por nombre, ID, mail o teléfono"
                aria-label="Buscar usuarios"
                autocomplete="off"
            >

            <button
                type="button"
                id="borrar-busqueda"
                class="buscador-borrar"
                aria-label="Borrar búsqueda"
                hidden
            >✕</button>

            <select id="campo" aria-label="Buscar en">
                <option value="todo">Todos los campos</option>
                <option value="usuario">Nombre</option>
                <option value="id">ID</option>
                <option value="mail">Mail</option>
                <option value="tel">Teléfono</option>
            </select>
        </div>

        <div class="chips-usuarios" role="group" aria-label="Filtrar por rango">
            <button type="button" class="chip-usuario activo"
                    data-rango="Todos" aria-pressed="true">
                Todos <span class="chip-num">0</span>
            </button>
            <button type="button" class="chip-usuario"
                    data-rango="Directivo" aria-pressed="false">
                Directivos <span class="chip-num">0</span>
            </button>
            <button type="button" class="chip-usuario"
                    data-rango="Bibliotecario" aria-pressed="false">
                Bibliotecarios <span class="chip-num">0</span>
            </button>
            <button type="button" class="chip-usuario"
                    data-rango="Alumno" aria-pressed="false">
                Alumnos <span class="chip-num">0</span>
            </button>
        </div>

        <div id="filtros-cursos" class="filtros-cursos" hidden>
            <p>Filtrar alumnos por curso</p>
            <div id="chips-cursos" class="chips-usuarios"
                 role="group" aria-label="Filtrar por curso"></div>
        </div>

        <p id="contador-usuarios" class="contador-usuarios"
           role="status" aria-live="polite"></p>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Curso o función</th>
                        <th>Mail</th>
                        <th>Teléfono</th>
                    </tr>
                </thead>
                <tbody id="feed-contenedores"></tbody>
            </table>
        </div>

        <p id="sin-resultados" class="sin-resultados-usuarios" hidden>
            No se encontraron usuarios con esos filtros.
        </p>
        <p class="error-tabla" id="error-tabla" hidden>
            No se pudieron cargar los usuarios. Revisá que el servidor
            esté encendido; se volverá a intentar automáticamente.
        </p>
    </div>
</main>

<a href="../agregar_alumno/Agregar_alumno.php"
   class="btn-agregar" aria-label="Agregar usuario">
    <svg class="btn-agregar-icono" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round"
         aria-hidden="true">
        <line x1="12" y1="5" x2="12" y2="19"/>
        <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
    <span class="btn-agregar-texto">Agregar usuario</span>
</a>

<script>
const estado = { registros: [], rango: 'Todos', curso: 'Todos' };
const cuerpo = document.getElementById('feed-contenedores');
const input = document.getElementById('busqueda');
const campo = document.getElementById('campo');
const errorTabla = document.getElementById('error-tabla');
const filtrosCursos = document.getElementById('filtros-cursos');
const chipsCursos = document.getElementById('chips-cursos');
const chipsRango = [...document.querySelectorAll('[data-rango]')];

const normalizar = valor =>
    String(valor ?? '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

const rangoDe = registro => normalizar(registro.rango);

function crearChip(curso, total) {
    const boton = document.createElement('button');
    boton.type = 'button';
    boton.className =
        'chip-usuario' + (estado.curso === curso ? ' activo' : '');
    boton.dataset.curso = curso;
    boton.setAttribute(
        'aria-pressed',
        estado.curso === curso ? 'true' : 'false'
    );
    boton.append(document.createTextNode(curso + ' '));

    const contador = document.createElement('span');
    contador.className = 'chip-num';
    contador.textContent = total;
    boton.append(contador);

    boton.addEventListener('click', () => {
        estado.curso = curso;
        actualizar();
    });

    return boton;
}

function buscar(registro, palabras) {
    const campos = campo.value === 'todo'
        ? ['usuario', 'id', 'mail', 'tel']
        : [campo.value];

    const texto = campos
        .map(clave => normalizar(registro[clave]))
        .join(' ');

    return palabras.every(palabra => texto.includes(palabra));
}

function actualizar() {
    const palabras = normalizar(input.value.trim())
        .split(/\s+/)
        .filter(Boolean);

    const encontrados = estado.registros.filter(
        registro => buscar(registro, palabras)
    );

    chipsRango.forEach(chip => {
        const cantidad = encontrados.filter(registro =>
            chip.dataset.rango === 'Todos'
            || rangoDe(registro) === normalizar(chip.dataset.rango)
        ).length;

        chip.querySelector('.chip-num').textContent = cantidad;
        chip.classList.toggle(
            'activo',
            estado.rango === chip.dataset.rango
        );
        chip.setAttribute(
            'aria-pressed',
            estado.rango === chip.dataset.rango ? 'true' : 'false'
        );
    });

    filtrosCursos.hidden = estado.rango !== 'Alumno';

    if (estado.rango === 'Alumno') {
        const alumnos = encontrados.filter(
            registro => rangoDe(registro) === 'alumno'
        );

        const cursos = new Map();

        alumnos.forEach(registro => {
            const curso =
                String(registro.curso_actual ?? '').trim() || 'Sin curso';

            cursos.set(curso, (cursos.get(curso) ?? 0) + 1);
        });

        chipsCursos.replaceChildren(
            crearChip('Todos', alumnos.length),
            ...[...cursos]
                .sort((a, b) =>
                    a[0].localeCompare(b[0], 'es', { numeric: true })
                )
                .map(([curso, total]) => crearChip(curso, total))
        );
    }

    let visibles = 0;

    for (const registro of estado.registros) {
        const fila = cuerpo.querySelector(
            'tr[data-id="' + registro.id + '"]'
        );

        if (!fila) continue;

        const curso =
            String(registro.curso_actual ?? '').trim() || 'Sin curso';

        const mostrar =
            buscar(registro, palabras)
            && (
                estado.rango === 'Todos'
                || rangoDe(registro) === normalizar(estado.rango)
            )
            && (
                estado.rango !== 'Alumno'
                || estado.curso === 'Todos'
                || curso === estado.curso
            );

        fila.hidden = !mostrar;
        if (mostrar) visibles++;
    }

    document.getElementById('contador-usuarios').textContent =
        `Mostrando ${visibles} ${visibles === 1 ? 'usuario' : 'usuarios'}`;

    document.getElementById('sin-resultados').hidden =
        visibles !== 0 || estado.registros.length === 0;

    document.getElementById('borrar-busqueda').hidden =
        input.value === '';
}

function crearFila(registro) {
    const fila = document.createElement('tr');
    fila.dataset.id = registro.id;

    const urlId = encodeURIComponent(registro.id);
    const nombre = document.createElement('td');
    const enlace = document.createElement('a');

    enlace.className = 'nombre-alumno';
    enlace.href =
        '../Carnet_De_Estudiante/Archivos_Ficha_De_Estudiantes/carnet.php?id='
        + urlId;
    enlace.textContent = registro.usuario ?? '';

    nombre.append(enlace);
    fila.append(nombre);

    for (const clave of ['curso_actual', 'mail', 'tel']) {
        const celda = document.createElement('td');
        celda.textContent = clave === 'curso_actual' && rangoDe(registro) !== 'alumno'
            ? registro.rango ?? ''
            : registro[clave] ?? '';
        fila.append(celda);
    }

    return fila;
}

let cargando = false;

async function pedirNuevosDatos() {
    if (cargando) return;
    cargando = true;

    try {
        const respuesta = await fetch(
            'obtener_datos.php',
            { cache: 'no-store' }
        );

        if (respuesta.status === 401 || respuesta.status === 403) {
            location.reload();
            return;
        }

        if (!respuesta.ok) {
            throw new Error(`Error HTTP: ${respuesta.status}`);
        }

        const registros = await respuesta.json();

        if (!Array.isArray(registros)) {
            throw new Error('Formato de datos inesperado');
        }

        estado.registros = registros.filter(registro =>
            Number.isSafeInteger(Number(registro.id))
            && Number(registro.id) > 0
        );

        const fragmento = document.createDocumentFragment();

        for (const registro of estado.registros.slice().reverse()) {
            fragmento.append(crearFila(registro));
        }

        cuerpo.replaceChildren(fragmento);
        errorTabla.hidden = true;
        actualizar();

    } catch (error) {
        console.error('Error al obtener los datos:', error);
        errorTabla.hidden = false;
    } finally {
        cargando = false;
    }
}

input.addEventListener('input', actualizar);

input.addEventListener('keydown', evento => {
    if (evento.key === 'Escape') {
        input.value = '';
        actualizar();
    }
});

document.getElementById('borrar-busqueda')
    .addEventListener('click', () => {
        input.value = '';
        actualizar();
        input.focus();
    });

campo.addEventListener('change', actualizar);

chipsRango.forEach(chip => {
    chip.addEventListener('click', () => {
        estado.rango = chip.dataset.rango;
        estado.curso = 'Todos';
        actualizar();
    });
});

pedirNuevosDatos();
setInterval(pedirNuevosDatos, 2000);

const header = document.getElementById('header');
let ultimoScroll = 0;

window.addEventListener('scroll', () => {
    const actual = window.pageYOffset;

    if (actual <= 0) {
        header.classList.remove('scroll-down');
        return;
    }

    if (actual > ultimoScroll && actual > 100) {
        header.classList.remove('scroll-up');
        header.classList.add('scroll-down');
    } else {
        header.classList.remove('scroll-down');
        header.classList.add('scroll-up');
    }

    ultimoScroll = actual;
});
</script>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
