# Biblioteca Común — versión clásica

Proyecto PHP para la Biblioteca Común de Villa Gardel.

## Inicio

1. Copiá esta carpeta a tu servidor PHP (por ejemplo, `htdocs`).
2. Conservá tu base MySQL `bibloteca`. El archivo `base_de_datos/bibloteca.sql` se incluye sin modificaciones para instalaciones nuevas; no lo importes sobre una base con datos que querés conservar.
3. Abrí `Pagina_Principal/pagina_principal_biblioteca/Pagina_principal.php` en el navegador.

Se utiliza la configuración MySQL incluida en el proyecto (`localhost`, usuario `root`, contraseña vacía), PHP 8.2 con `mysqli`, `mysqlnd` y `PDO MySQL`. Si tu servidor usa otras credenciales, ajustá solamente los archivos de conexión, sin renombrar `bibloteca`.

## Páginas

- La esquina superior izquierda vuelve a la página principal desde inicio de sesión, biblioteca, tabla y tarjeta personal. En los formularios y fichas vuelve a su página anterior.
- El nombre y rango del encabezado abren `tarjeta_de_usuario/tarjeta.php`. Ahí se encuentran el cambio de contraseña, el cierre de sesión y el botón para ver las sanciones propias.
- Bibliotecarios y directivos pueden acceder a la tabla, agregar usuarios, agregar libros, asignar sanciones a otros usuarios y editar el curso de alumnos. Los directivos también pueden quitar sanciones después de confirmar.
- El formulario de usuarios muestra el curso solamente al seleccionar Alumno, o la función al seleccionar Trabajador de la institución.

El diseño mantiene el rojo y los tonos cálidos de la página principal, con ajustes para celular, tableta y computadora. El inicio de sesión muestra la foto a la izquierda y el formulario a la derecha; en el carnet, el directivo confirma en una ventana que indica el motivo y el usuario antes de quitar una sanción.

## Estilos

- `assets/styles.css` contiene los estilos generales y de sesión para todas las páginas.
- `assets/formularios.css` se comparte entre agregar libro, agregar usuario, dar sanción y sus páginas de resultado.
- Cada sección restante utiliza su propio `styles.css` o un CSS con el nombre de su página. Inicio de sesión y cambio de contraseña conservan archivos distintos porque usan estructuras y selectores diferentes.
