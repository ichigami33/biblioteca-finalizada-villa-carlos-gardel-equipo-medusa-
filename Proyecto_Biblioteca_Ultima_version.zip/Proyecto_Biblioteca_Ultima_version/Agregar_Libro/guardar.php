<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);
mysqli_report(MYSQLI_REPORT_OFF);
$urlBiblioteca = '../Biblioteca_Comun/Archivos_Biblioteca_Comun/Pagina_Biblioteca_Comun.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: Agregar_libro.php");
    exit;
}

$exito = false;
$mensaje = "Ocurrió un problema al guardar el libro.";
$isbn = is_string($_POST["isbn"] ?? null) ? trim($_POST["isbn"]) : "";
$nombrel = is_string($_POST["nombrel"] ?? null) ? trim($_POST["nombrel"]) : "";
$autor = is_string($_POST["autor"] ?? null) ? trim($_POST["autor"]) : "";
$editorial = is_string($_POST["editorial"] ?? null) ? trim($_POST["editorial"]) : "";
$tema = is_string($_POST["tema"] ?? null) ? trim($_POST["tema"]) : "";
$stock = is_string($_POST["stock"] ?? null) ? trim($_POST["stock"]) : "";
$token = $_POST['csrf'] ?? null;

$longitud = static fn($texto) => function_exists('mb_strlen') ? mb_strlen($texto, 'UTF-8') : strlen($texto);
try {
    include __DIR__ . '/conexion.php';

    if (!is_string($token) || !isset($_SESSION['nuevo_libro_csrf']) || !hash_equals($_SESSION['nuevo_libro_csrf'], $token)) {
        http_response_code(403);
        $mensaje = "El formulario venció. Volvé a abrir Agregar libro e intentá nuevamente.";
    } elseif ($isbn === "" || $nombrel === "" || $autor === "" || $editorial === "" || $tema === "" || $stock === "") {
        $mensaje = "Completá todos los campos antes de guardar el libro.";
    } elseif (!ctype_digit($isbn) || !ctype_digit($tema) || !ctype_digit($stock)) {
        $mensaje = "Los datos ingresados no tienen un formato válido.";
    } elseif ((int)$isbn < 1 || (int)$isbn > 2147483647) {
        $mensaje = "El ISBN debe estar entre 1 y 2147483647, el límite de la base de datos.";
    } elseif ((int)$tema < 1 || (int)$tema > 10) {
        $mensaje = "El género seleccionado no es válido.";
    } elseif ((int)$stock < 0 || (int)$stock > 99) {
        $mensaje = "La cantidad disponible debe estar entre 0 y 99.";
    } elseif ($longitud($nombrel) > 30) {
        $mensaje = "El título del libro no puede superar los 30 caracteres.";
    } elseif ($longitud($autor) > 20) {
        $mensaje = "El nombre del autor no puede superar los 20 caracteres.";
    } elseif ($longitud($editorial) > 30) {
        $mensaje = "La editorial no puede superar los 30 caracteres.";
    } else {
        $isbn = (int)$isbn;
        $tema = (int)$tema;
        $stock = (int)$stock;
        $sql = "INSERT INTO librost (isbn, tema, autor, editorial, stock, nombrel) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conexion, $sql);
        if (!$stmt) {
            $mensaje = "No se pudo preparar el guardado del libro.";
        } else {
            mysqli_stmt_bind_param($stmt, "iissis", $isbn, $tema, $autor, $editorial, $stock, $nombrel);
            if (mysqli_stmt_execute($stmt)) {
                $exito = true;
                $_SESSION['nuevo_libro_csrf'] = bin2hex(random_bytes(32));
            } else {
                $codigo_error = mysqli_stmt_errno($stmt);
                if ($codigo_error === 1062) {
                    $mensaje = "Ya existe un libro registrado con ese ISBN.";
                } elseif ($codigo_error === 1264) {
                    $mensaje = "El ISBN ingresado supera el tamaño máximo que admite la base de datos (2147483647).";
                } elseif ($codigo_error === 1406) {
                    $mensaje = "Alguno de los textos ingresados es demasiado largo para guardarse.";
                } else {
                    $mensaje = "No se pudo guardar el libro. Revisá los datos e intentá nuevamente.";
                }
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($conexion);
} catch (Throwable $e) {
    $mensaje = "No se pudo conectar con la base de datos. Verificá que el servidor esté encendido e intentá nuevamente.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $exito ? 'Libro agregado' : 'Error' ?> | Biblioteca Común</title>
    <link rel="stylesheet" href="../assets/formularios.css?v=<?= (int)filemtime(__DIR__ . '/../assets/formularios.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a href="<?= h($urlBiblioteca) ?>" class="marca">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Registro de libro</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main class="contenido">
        <section class="exito<?= $exito ? '' : ' error' ?>">
            <div class="exito-icono"><?= $exito ? '✓' : '✕' ?></div>
            <p class="formulario-etiqueta">BIBLIOTECA COMÚN</p>
            <?php if ($exito): ?>
            <h1>Libro agregado correctamente</h1>
            <p><strong><?= h($nombrel) ?></strong> fue agregado al catálogo de la biblioteca.</p>
            <div class="acciones">
                <a href="<?= h($urlBiblioteca) ?>" class="boton-volver">Ir a la biblioteca</a>
                <a href="Agregar_libro.php" class="boton-guardar">Agregar otro libro</a>
            </div>
            <?php else: ?>
            <h1>No se pudo agregar el libro</h1>
            <p><?= h($mensaje) ?></p>
            <div class="acciones">
                <a href="Agregar_libro.php" class="boton-guardar">Volver a intentar</a>
                <a href="<?= h($urlBiblioteca) ?>" class="boton-volver">Ir a la biblioteca</a>
            </div>
            <?php endif; ?>
        </section>
    </main>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
