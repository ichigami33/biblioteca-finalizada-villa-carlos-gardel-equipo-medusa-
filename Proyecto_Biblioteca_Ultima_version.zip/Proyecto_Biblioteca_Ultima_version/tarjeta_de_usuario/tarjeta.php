<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_sesion($raiz);
header('Cache-Control: no-store, no-cache, must-revalidate');

$id = (int)$_SESSION['id'];

try {
    require_once __DIR__ . '/../Inicio_Sesion/conexion.php';

    $stmt = $conexion->prepare(
        'SELECT id, usuario, tel, mail, rango, curso_actual
         FROM usuarios
         WHERE id = ?'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();

    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($usuario) {
        $stmt = $conexion->prepare('SELECT sans1 FROM sansl WHERE id = ? ORDER BY sans1');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $sanciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
    $conexion->close();
} catch (Throwable $e) {
    mostrar_error(
        $raiz,
        'Error de conexión',
        'No se pudo cargar tu tarjeta. Intentá nuevamente.',
        [
            ['Volver a intentar', 'tarjeta.php'],
            ['Ir al inicio', url_principal($raiz)]
        ],
        500
    );
}

if (!$usuario) {
    mostrar_error(
        $raiz,
        'Usuario no encontrado',
        'Tu usuario ya no está registrado en el sistema.',
        [['Volver al inicio', url_principal($raiz)]],
        404
    );
}

$esAlumno = strcasecmp(trim((string)$usuario['rango']), 'Alumno') === 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi tarjeta de usuario | Biblioteca Común</title>
    <link rel="stylesheet" href="tarjeta.css?v=<?= (int)filemtime(__DIR__ . '/tarjeta.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
<header>
    <a class="marca" href="<?= h(url_principal($raiz)) ?>">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round"
             aria-hidden="true">
            <path d="M4 5.5C4 4.7 4.7 4 5.5 4H11v15H5.5C4.7 19 4 18.3 4 17.5v-12z"/>
            <path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H13v15h5.5c.8 0 1.5-.7 1.5-1.5v-12z"/>
        </svg>
        <span>Biblioteca Virtual</span>
    </a>
        <span class="contexto-header" aria-label="Sección actual">Mi tarjeta</span>
    <?php mostrar_sesion($raiz); ?>
</header>

<div class="sub-header">
    <span>Biblioteca Virtual</span>
    <span class="separador">•</span>
    <strong>Villa Gardel</strong>
</div>

<main>
    <section class="tarjeta" aria-labelledby="titulo-tarjeta">
        <div class="titulo-tarjeta">
            <h1 id="titulo-tarjeta">MI TARJETA DE USUARIO</h1>
        </div>

        <div class="datos">
            <div class="dato">
                <span class="etiqueta">NOMBRE</span>
                <strong><?= h($usuario['usuario']) ?></strong>
            </div>

            <div class="dato">
                <span class="etiqueta">ID</span>
                <strong><?= (int)$usuario['id'] ?></strong>
            </div>

            <div class="dato">
                <span class="etiqueta">MAIL</span>
                <strong><?= h($usuario['mail']) ?></strong>
            </div>

            <div class="dato">
                <span class="etiqueta">TELÉFONO</span>
                <strong><?= h($usuario['tel']) ?></strong>
            </div>

            <div class="dato <?= $esAlumno ? '' : 'ancho' ?>">
                <span class="etiqueta">RANGO EN EL SISTEMA</span>
                <strong><?= h($usuario['rango']) ?></strong>
            </div>

            <?php if ($esAlumno): ?>
                <div class="dato">
                    <span class="etiqueta">CURSO</span>
                    <strong><?= h($usuario['curso_actual']) ?></strong>
                </div>
            <?php endif; ?>
        </div>

        <details class="sanciones-propias">
            <summary>Ver mis sanciones <span class="cantidad-sanciones"><?= count($sanciones) ?></span></summary>
            <div class="sanciones-contenido">
                <?php if (!$sanciones): ?>
                    <p class="sin-sanciones">No tenés sanciones activas.</p>
                <?php else: ?>
                    <ul>
                        <?php foreach ($sanciones as $sancion): ?>
                            <li><?= h($sancion['sans1']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </details>

        <div class="acciones">
            <a class="boton" href="../Inicio_Sesion/cambiar_contrasena.php">
                Cambiar contraseña
            </a>
            <a class="boton secundario" href="<?= h(url_logout($raiz)) ?>">
                Cerrar sesión
            </a>
        </div>
    </section>
</main>

<footer>
    Todos los derechos reservados — Grupo Medusa
</footer>
</body>
</html>
