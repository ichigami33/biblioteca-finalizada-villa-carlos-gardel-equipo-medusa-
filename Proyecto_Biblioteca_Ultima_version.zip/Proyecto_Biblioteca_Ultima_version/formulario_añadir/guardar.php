<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);
mysqli_report(MYSQLI_REPORT_OFF);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../tabla_usuarios/pagina_tabla_usuarios.php');
    exit;
}

$exito = false;
$mensaje = 'Ocurrió un problema al crear la sanción.';
$valorId = $_POST['id'] ?? null;
$id = is_string($valorId) && ctype_digit($valorId) && (int)$valorId > 0 ? (int)$valorId : 0;
$valorMotivo = $_POST['sans1'] ?? null;
$sans1 = is_string($valorMotivo) ? trim($valorMotivo) : '';
$token = $_POST['csrf'] ?? null;
$idDestinatario = is_string($token) && isset($_SESSION['sancion_destinos'][$token])
    ? (int)$_SESSION['sancion_destinos'][$token]
    : 0;
$urlFormulario = $idDestinatario > 0 ? 'Agregar_sancion.php?id=' . $idDestinatario : '../tabla_usuarios/pagina_tabla_usuarios.php';
$urlCarnet = $idDestinatario > 0 ? '../Carnet_De_Estudiante/Archivos_Ficha_De_Estudiantes/carnet.php?id=' . $idDestinatario : '../tabla_usuarios/pagina_tabla_usuarios.php';

if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token) || $idDestinatario === 0) {
    http_response_code(403);
    $mensaje = 'El formulario venció. Elegí nuevamente el usuario desde la tabla.';
} elseif ($id === 0 || $id !== $idDestinatario) {
    http_response_code(400);
    $mensaje = 'El usuario indicado no coincide con el que elegiste en la tabla.';
} elseif ($id === (int)$_SESSION['id']) {
    http_response_code(403);
    $mensaje = 'No podés agregarte una sanción a vos mismo.';
} elseif ($sans1 === '') {
    http_response_code(400);
    $mensaje = 'Completá el motivo de la sanción antes de guardarla.';
} elseif ((function_exists('mb_strlen') ? mb_strlen($sans1, 'UTF-8') : strlen($sans1)) > 999) {
    http_response_code(400);
    $mensaje = 'El texto de la sanción debe tener hasta 999 caracteres.';
} else {
    try {
        include __DIR__ . '/conexion.php';
        $verificar = mysqli_prepare($conexion, 'SELECT id FROM usuarios WHERE id = ?');
        if (!$verificar) {
            $mensaje = 'No se pudo verificar el usuario.';
        } else {
            mysqli_stmt_bind_param($verificar, 'i', $id);
            if (!mysqli_stmt_execute($verificar)) {
                $mensaje = 'No se pudo verificar el usuario.';
            } else {
                mysqli_stmt_store_result($verificar);
                if (mysqli_stmt_num_rows($verificar) === 0) {
                    $mensaje = 'El usuario ya no existe en el sistema.';
                } else {
                    $stmt = mysqli_prepare($conexion, 'INSERT INTO sansl (id, sans1) VALUES (?, ?)');
                    if (!$stmt) {
                        $mensaje = 'No se pudo preparar el guardado de la sanción.';
                    } else {
                        mysqli_stmt_bind_param($stmt, 'is', $id, $sans1);
                        if (mysqli_stmt_execute($stmt)) {
                            $exito = true;
                            unset($_SESSION['sancion_destinos'][$token]);
                        } else {
                            $codigoError = mysqli_stmt_errno($stmt);
                            if ($codigoError === 1062) {
                                $mensaje = 'Ya existe una sanción que impide guardar otra para este usuario.';
                            } elseif ($codigoError === 1264) {
                                $mensaje = 'El ID supera el tamaño que admite la base de datos.';
                            } elseif ($codigoError === 1406) {
                                $mensaje = 'El texto de la sanción supera el tamaño que admite la base de datos.';
                            } else {
                                $mensaje = 'No se pudo guardar la sanción. Revisá los datos e intentá nuevamente.';
                            }
                        }
                        mysqli_stmt_close($stmt);
                    }
                }
            }
            mysqli_stmt_close($verificar);
        }
        mysqli_close($conexion);
    } catch (Throwable $e) {
        $mensaje = 'No se pudo conectar con la base de datos. Intentá nuevamente.';
    }
}
if (!$exito && http_response_code() === 200) {
    http_response_code(500);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $exito ? 'Sanción agregada' : 'Error al agregar sanción' ?> | Biblioteca Común</title>
    <link rel="stylesheet" href="../assets/formularios.css?v=<?= (int)filemtime(__DIR__ . '/../assets/formularios.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a href="<?= h($urlCarnet) ?>" class="marca">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Registro de sanción</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main class="contenido">
        <section class="exito<?= $exito ? '' : ' error' ?>">
            <div class="exito-icono"><?= $exito ? '✓' : '✕' ?></div>
            <p class="formulario-etiqueta">BIBLIOTECA COMÚN</p>
            <?php if ($exito): ?>
            <h1>Sanción creada correctamente</h1>
            <p>El usuario con ID <strong><?= (int)$id ?></strong> recibió la sanción especificada.</p>
            <div class="acciones">
                <a href="Agregar_sancion.php?id=<?= (int)$id ?>" class="boton-guardar">Agregar otra sanción</a>
                <a href="../Carnet_De_Estudiante/Archivos_Ficha_De_Estudiantes/carnet.php?id=<?= (int)$id ?>#sanciones" class="boton-volver">Ver carnet</a>
            </div>
            <?php else: ?>
            <h1>No se pudo agregar la sanción</h1>
            <p><?= h($mensaje) ?></p>
            <div class="acciones">
                <a href="<?= h($urlFormulario) ?>" class="boton-guardar">Volver a intentar</a>
            </div>
            <?php endif; ?>
        </section>
    </main>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
