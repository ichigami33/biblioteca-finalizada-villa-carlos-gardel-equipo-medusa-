<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id) {
    mostrar_error($raiz, 'Usuario no válido', 'Elegí un usuario desde la tabla para agregarle una sanción.', [['Volver a la tabla', '../tabla_usuarios/pagina_tabla_usuarios.php']], 400);
}
if ((int)$id === (int)$_SESSION['id']) {
    mostrar_error($raiz, 'Acción no permitida', 'No podés agregarte una sanción a vos mismo.', [['Volver a mi tarjeta', url_carnet($raiz)]], 403);
}
try {
    require_once __DIR__ . '/conexion.php';
    $stmt = $conexion->prepare('SELECT id, usuario, rango FROM usuarios WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $destinatario = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conexion->close();
} catch (Throwable $e) {
    mostrar_error($raiz, 'Error de conexión', 'No se pudo cargar el usuario.', [['Volver a la tabla', '../tabla_usuarios/pagina_tabla_usuarios.php']], 500);
}
if (!$destinatario) {
    mostrar_error($raiz, 'Usuario no encontrado', 'No existe el usuario seleccionado.', [['Volver a la tabla', '../tabla_usuarios/pagina_tabla_usuarios.php']], 404);
}
$tokenFormulario = bin2hex(random_bytes(32));
$_SESSION['sancion_destinos'][$tokenFormulario] = (int)$id;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dar sanción | Biblioteca Común</title>
    <link rel="stylesheet" href="../assets/formularios.css?v=<?= (int)filemtime(__DIR__ . '/../assets/formularios.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a href="../Carnet_De_Estudiante/Archivos_Ficha_De_Estudiantes/carnet.php?id=<?= (int)$id ?>" class="marca">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Añadir sanción</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main class="contenido">
        <section class="formulario-contenedor">
            <div class="formulario-cabecera">
                <span class="formulario-icono"><b>✕</b></span>
                <div><p class="formulario-etiqueta">Sanciones</p><h1>Dar sanción</h1><p>Completá la información.</p></div>
            </div>
            <div class="destinatario-sancion" aria-label="Usuario que recibirá la sanción">
                <span class="destinatario-avatar" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M4.5 20c.4-4 3-6 7.5-6s7.1 2 7.5 6"/></svg>
                </span>
                <div class="destinatario-datos">
                    <span class="destinatario-etiqueta">La sanción se asignará a</span>
                    <strong><?= h($destinatario['usuario']) ?></strong>
                    <div class="destinatario-meta"><span>ID <?= (int)$id ?></span><span><?= h($destinatario['rango']) ?></span></div>
                </div>
            </div>
            <form action="guardar.php" method="post" class="formulario-libro">
                <input type="hidden" name="id" value="<?= (int)$id ?>">
                <input type="hidden" name="csrf" value="<?= h($tokenFormulario) ?>">
                <div class="campo2">
                    <label for="sans1">Conducta a sancionar</label>
                    <textarea id="sans1" name="sans1" maxlength="999" required placeholder="Motivo por el cual recibe la sanción."></textarea>
                </div>
                <div class="acciones">
                    <a class="boton-volver" href="../Carnet_De_Estudiante/Archivos_Ficha_De_Estudiantes/carnet.php?id=<?= (int)$id ?>">Volver al carnet</a>
                    <button type="submit" class="boton-guardar">Crear sanción</button>
                </div>
            </form>
        </section>
    </main>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
