document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('form').forEach(form=>{
        form.addEventListener('submit',evento=>{
            queueMicrotask(()=>{
                if(evento.defaultPrevented || !form.checkValidity()) return;
                const button=form.querySelector('button[type="submit"]');
                if(button) button.setAttribute('aria-busy','true');
            });
        });
    });
});
