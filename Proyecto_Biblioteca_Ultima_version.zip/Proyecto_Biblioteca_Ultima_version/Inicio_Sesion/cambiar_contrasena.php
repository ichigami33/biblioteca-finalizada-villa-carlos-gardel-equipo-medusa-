<?php
require_once __DIR__ . '/sesion.php';
$raiz = '../';
exigir_sesion($raiz);
header('Cache-Control: no-store, no-cache, must-revalidate');

if (empty($_SESSION['clave_csrf'])) {
    $_SESSION['clave_csrf'] = bin2hex(random_bytes(32));
}
$error = '';
$exito = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf'] ?? null;
    $actual = $_POST['clave_actual'] ?? null;
    $nueva = $_POST['clave_nueva'] ?? null;
    $repetida = $_POST['clave_repetida'] ?? null;
    if (!is_string($token) || !hash_equals($_SESSION['clave_csrf'], $token)) {
        $error = 'El formulario venció. Recargá la página e intentá nuevamente.';
    } elseif (!is_string($actual) || !is_string($nueva) || !is_string($repetida)
        || $actual === '' || $nueva === '' || $repetida === '') {
        $error = 'Completá los tres campos.';
    } elseif ($nueva !== $repetida) {
        $error = 'La nueva contraseña y su confirmación no coinciden.';
    } elseif ((function_exists('mb_strlen') ? mb_strlen($nueva, 'UTF-8') : strlen($nueva)) < 8
        || (function_exists('mb_strlen') ? mb_strlen($nueva, 'UTF-8') : strlen($nueva)) > 500) {
        $error = 'La nueva contraseña debe tener entre 8 y 500 caracteres.';
    } else {
        try {
            require_once __DIR__ . '/conexion.php';
            $idSesion = (int)$_SESSION['id'];
            $conexion->begin_transaction();
            $stmt = $conexion->prepare('SELECT contraseña FROM usuarios WHERE id = ? FOR UPDATE');
            $stmt->bind_param('i', $idSesion);
            $stmt->execute();
            $datos = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$datos || !password_verify($actual, $datos['contraseña'])) {
                $error = 'La contraseña actual es incorrecta.';
                $conexion->rollback();
            } elseif (password_verify($nueva, $datos['contraseña'])) {
                $error = 'Elegí una contraseña distinta de la actual.';
                $conexion->rollback();
            } else {
                $hash = password_hash($nueva, PASSWORD_DEFAULT);
                $stmt = $conexion->prepare('UPDATE usuarios SET contraseña = ? WHERE id = ?');
                $stmt->bind_param('si', $hash, $idSesion);
                $stmt->execute();
                $stmt->close();
                $conexion->commit();
                session_regenerate_id(true);
                $_SESSION['clave_csrf'] = bin2hex(random_bytes(32));
                $exito = true;
            }
            $conexion->close();
        } catch (Throwable $e) {
            if (isset($conexion) && $conexion instanceof mysqli) {
                try { $conexion->rollback(); } catch (Throwable $ignorado) {}
                $conexion->close();
            }
            $error = 'No se pudo cambiar la contraseña. Intentá nuevamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar contraseña | Biblioteca Común</title>
    <link rel="stylesheet" href="cambiar_contrasena.css?v=<?= (int)filemtime(__DIR__ . '/cambiar_contrasena.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a class="marca" href="<?= h(url_carnet($raiz)) ?>">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Cambiar contraseña</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main>
        <section class="tarjeta">
            <h1>Cambiar contraseña</h1>
            <?php if ($exito): ?>
                <p class="mensaje exito" role="status">La contraseña se cambió correctamente.</p>
                <a class="boton" href="<?= h(url_carnet($raiz)) ?>">Volver a mi tarjeta de usuario</a>
            <?php else: ?>
                <p>Ingresá tu contraseña actual y elegí una nueva. La contraseña no se mostrará en tu carnet.</p>
                <?php if ($error !== ''): ?><p class="mensaje error" role="alert"><?= h($error) ?></p><?php endif; ?>
                <form method="post" autocomplete="on">
                    <input type="hidden" name="csrf" value="<?= h($_SESSION['clave_csrf']) ?>">
                    <label for="clave_actual">Contraseña actual</label>
                    <input type="password" id="clave_actual" name="clave_actual" autocomplete="current-password" required>
                    <label for="clave_nueva">Nueva contraseña (mínimo 8 caracteres)</label>
                    <input type="password" id="clave_nueva" name="clave_nueva" autocomplete="new-password" minlength="8" maxlength="500" required>
                    <label for="clave_repetida">Repetir nueva contraseña</label>
                    <input type="password" id="clave_repetida" name="clave_repetida" autocomplete="new-password" minlength="8" maxlength="500" required>
                    <button type="submit" class="boton">Guardar nueva contraseña</button>
                </form>
                <a class="boton" href="<?= h(url_carnet($raiz)) ?>">Volver a mi tarjeta de usuario</a>
            <?php endif; ?>
        </section>
    </main>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
