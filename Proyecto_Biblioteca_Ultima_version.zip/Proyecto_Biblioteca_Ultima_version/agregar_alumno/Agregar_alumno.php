<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);
if (empty($_SESSION['nuevo_usuario_csrf'])) $_SESSION['nuevo_usuario_csrf'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar usuario | Tabla de Usuarios</title>
    <link rel="stylesheet" href="../assets/formularios.css?v=<?= (int)filemtime(__DIR__ . '/../assets/formularios.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a href="../tabla_usuarios/pagina_tabla_usuarios.php" class="marca">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Agregar usuario</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main class="contenido">
        <section class="formulario-contenedor">
            <div class="formulario-cabecera">
                <span class="formulario-icono">+</span>
                <div>
                    <p class="formulario-etiqueta">Tabla de Usuarios</p>
                    <h1>Agregar usuario</h1>
                    <p>Completá los datos para registrar al usuario en el sistema.</p>
                </div>
            </div>

            <form action="guardar.php" method="post" class="formulario-libro" id="formulario-usuario">
                <input type="hidden" name="csrf" value="<?= h($_SESSION['nuevo_usuario_csrf']) ?>">
                <div class="campo">
                    <label for="usuario">Nombre de usuario</label>
                    <input type="text" id="usuario" name="usuario" maxlength="30" required placeholder="Ej: juanperez">
                </div>
                <div class="campo">
                    <label for="contraseña">Contraseña</label>
                    <input type="password" id="contraseña" name="contraseña" minlength="8" maxlength="500" required placeholder="Ingresá una contraseña">
                </div>
                <div class="campo">
                    <label for="tel">Teléfono</label>
                    <input type="number" id="tel" name="tel" min="1" max="2147483647" inputmode="numeric" required placeholder="Ej: 1123456789">
                </div>
                <div class="campo">
                    <label for="mail">Email</label>
                    <input type="email" id="mail" name="mail" maxlength="60" required placeholder="Ej: usuario@gmail.com">
                </div>
                <div class="fila-rango">
                    <div class="campo">
                        <label for="tipo_usuario">Rango en el sistema</label>
                        <select id="tipo_usuario" name="tipo_usuario" required>
                            <option value="">-- Seleccioná --</option>
                            <option value="alumno">Alumno</option>
                            <option value="trabajador">Trabajador de la institución</option>
                        </select>
                    </div>
                    <div class="campo" id="grupo-curso" hidden>
                        <label for="curso_actual">Curso</label>
                        <select id="curso_actual" name="curso_actual" disabled required>
                            <option value="">-- Seleccioná un curso --</option>
                            <?php foreach (range(1, 6) as $anio): ?>
                                <?php foreach (['A', 'B', 'C', 'D'] as $division): ?>
                                    <?php $curso = $anio . '°' . $division; ?>
                                    <option value="<?= h($curso) ?>"><?= h($curso) ?></option>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" id="rango_alumno" name="rango" value="Alumno" disabled>
                    </div>
                    <div class="campo" id="grupo-empleado" hidden>
                        <label for="rango_empleado">Función en el sistema</label>
                        <select id="rango_empleado" name="rango" disabled required>
                            <option value="">-- Seleccioná una función --</option>
                            <option value="Bibliotecario">Bibliotecario</option>
                            <option value="Directivo">Directivo</option>
                        </select>
                        <input type="hidden" id="curso_trabajador" name="curso_actual" value="trabajador" disabled>
                    </div>
                </div>
                <div class="acciones">
                    <a class="boton-volver" href="../tabla_usuarios/pagina_tabla_usuarios.php">Volver a la Tabla de Usuarios</a>
                    <button type="submit" class="boton-guardar">Guardar usuario</button>
                </div>
            </form>
            <noscript>Activá JavaScript para elegir el curso o la función del usuario.</noscript>
        </section>
    </main>
    <script>
        const tipoUsuario = document.getElementById('tipo_usuario');
        const grupoCurso = document.getElementById('grupo-curso');
        const grupoEmpleado = document.getElementById('grupo-empleado');
        const cursoActual = document.getElementById('curso_actual');
        const rangoAlumno = document.getElementById('rango_alumno');
        const rangoEmpleado = document.getElementById('rango_empleado');
        const cursoTrabajador = document.getElementById('curso_trabajador');

        function actualizarRango() {
            const esAlumno = tipoUsuario.value === 'alumno';
            const esTrabajador = tipoUsuario.value === 'trabajador';
            grupoCurso.hidden = !esAlumno;
            grupoEmpleado.hidden = !esTrabajador;
            cursoActual.disabled = !esAlumno;
            rangoAlumno.disabled = !esAlumno;
            rangoEmpleado.disabled = !esTrabajador;
            cursoTrabajador.disabled = !esTrabajador;
            if (!esAlumno) cursoActual.value = '';
            if (!esTrabajador) rangoEmpleado.value = '';
        }

        tipoUsuario.addEventListener('change', actualizarRango);
        actualizarRango();
    </script>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
