<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_admin($raiz);
mysqli_report(MYSQLI_REPORT_OFF);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: Agregar_alumno.php");
    exit;
}

$exito = false;
$mensaje = "Ocurrió un problema al registrar el usuario.";
$alumno = is_string($_POST["usuario"] ?? null) ? trim($_POST["usuario"]) : "";
$contraseña = is_string($_POST["contraseña"] ?? null) ? $_POST["contraseña"] : "";
$tel = is_string($_POST["tel"] ?? null) ? trim($_POST["tel"]) : "";
$mail = is_string($_POST["mail"] ?? null) ? trim($_POST["mail"]) : "";
$curso_actual = is_string($_POST["curso_actual"] ?? null) ? trim($_POST["curso_actual"]) : "";
$rango = is_string($_POST["rango"] ?? null) ? trim($_POST["rango"]) : "";
$token = $_POST['csrf'] ?? null;

$tipo = is_string($_POST['tipo_usuario'] ?? null) ? $_POST['tipo_usuario'] : '';
$cursos = [];
foreach (range(1, 6) as $anio) foreach (['A', 'B', 'C', 'D'] as $division) $cursos[] = $anio . '°' . $division;
$longitud = static fn($texto) => function_exists('mb_strlen') ? mb_strlen($texto, 'UTF-8') : strlen($texto);
try {
    include __DIR__ . '/conexion.php';

    if (!is_string($token) || !isset($_SESSION['nuevo_usuario_csrf']) || !hash_equals($_SESSION['nuevo_usuario_csrf'], $token)) {
        http_response_code(403);
        $mensaje = "El formulario venció. Volvé a abrir Agregar usuario e intentá nuevamente.";
    } elseif ($alumno === "" || $contraseña === "" || $tel === "" || $mail === "" || $curso_actual === "" || $rango === "") {
        $mensaje = "Completá todos los campos antes de guardar el usuario.";
    } elseif ($longitud($alumno) > 30) {
        $mensaje = "El nombre de usuario no puede superar los 30 caracteres.";
    } elseif ($longitud($contraseña) < 8 || $longitud($contraseña) > 500) {
        $mensaje = "La contraseña debe tener entre 8 y 500 caracteres.";
    } elseif (!ctype_digit($tel)) {
        $mensaje = "El teléfono debe contener solamente números.";
    } elseif ((int)$tel < 1 || (int)$tel > 2147483647) {
        $mensaje = "El teléfono debe estar entre 1 y 2147483647, el límite de la base de datos.";
    } elseif (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "Ingresá un correo electrónico válido.";
    } elseif ($longitud($mail) > 60) {
        $mensaje = "El correo electrónico no puede superar los 60 caracteres.";
    } elseif ($tipo === "alumno" && ($rango !== "Alumno" || !in_array($curso_actual, $cursos, true))) {
        $mensaje = "Para un alumno, elegí un curso válido entre 1°A y 6°D.";
    } elseif ($tipo === "trabajador" && (!in_array($rango, ["Bibliotecario", "Directivo"], true) || $curso_actual !== "trabajador")) {
        $mensaje = "Para un trabajador, elegí Bibliotecario o Directivo.";
    } elseif (!in_array($tipo, ["alumno", "trabajador"], true)) {
        $mensaje = "Elegí si el usuario es alumno o trabajador de la institución.";
    } elseif (!in_array($rango, ["Alumno", "Bibliotecario", "Directivo"], true)) {
        $mensaje = "El rango seleccionado no es válido.";
    } else {
        $hash = password_hash($contraseña, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (usuario, contraseña, tel, mail, sans, libros, curso_actual, rango) VALUES (?, ?, ?, ?, 0, 0, ?, ?)";
        $stmt = mysqli_prepare($conexion, $sql);
        if (!$stmt) {
            $mensaje = "No se pudo preparar el registro del usuario.";
        } else {
            mysqli_stmt_bind_param($stmt, "ssssss", $alumno, $hash, $tel, $mail, $curso_actual, $rango);
            if (mysqli_stmt_execute($stmt)) {
                $exito = true;
                $_SESSION['nuevo_usuario_csrf'] = bin2hex(random_bytes(32));
            } else {
                $codigo_error = mysqli_stmt_errno($stmt);
                $detalle = mysqli_stmt_error($stmt);
                preg_match("/for key '(?:\w+\.)?(\w+)'/", $detalle, $clave);
                $clave = $clave[1] ?? "";
                if ($codigo_error === 1062 && $clave === "mail") {
                    $mensaje = "Ese correo electrónico ya está registrado en otro usuario.";
                } elseif ($codigo_error === 1062 && $clave === "tel") {
                    $mensaje = "Ese teléfono ya está registrado en otro usuario.";
                } elseif ($codigo_error === 1062) {
                    $mensaje = "Ese nombre de usuario ya está registrado.";
                } elseif ($codigo_error === 1264) {
                    $mensaje = "Alguno de los números ingresados supera el tamaño que admite la base de datos (por ejemplo, el teléfono).";
                } elseif ($codigo_error === 1406) {
                    $mensaje = "Alguno de los datos ingresados es demasiado largo para guardarse.";
                } else {
                    $mensaje = "No se pudo registrar el usuario. Revisá los datos e intentá nuevamente.";
                }
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($conexion);
} catch (Throwable $e) {
    $mensaje = "No se pudo conectar con la base de datos. Verificá que el servidor esté encendido e intentá nuevamente.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $exito ? 'Usuario agregado' : 'Error' ?> | Tabla de Usuarios</title>
    <link rel="stylesheet" href="../assets/formularios.css?v=<?= (int)filemtime(__DIR__ . '/../assets/formularios.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
    <header>
        <a href="../tabla_usuarios/pagina_tabla_usuarios.php" class="marca">Biblioteca Virtual</a>
        <span class="contexto-header" aria-label="Sección actual">Registro de usuario</span>
        <?php mostrar_sesion($raiz); ?>
    </header>
    <main class="contenido">
        <section class="exito<?= $exito ? '' : ' error' ?>">
            <div class="exito-icono"><?= $exito ? '✓' : '✕' ?></div>
            <p class="formulario-etiqueta">TABLA DE USUARIOS</p>
            <?php if ($exito): ?>
            <h1>Usuario agregado correctamente</h1>
            <p>El usuario <strong><?= h($alumno) ?></strong> fue registrado correctamente en el sistema.</p>
            <div class="acciones">
                <a href="../tabla_usuarios/pagina_tabla_usuarios.php" class="boton-volver">Ir a la Tabla de Usuarios</a>
                <a href="Agregar_alumno.php" class="boton-guardar">Agregar otro usuario</a>
            </div>
            <?php else: ?>
            <h1>No se pudo agregar el usuario</h1>
            <p><?= h($mensaje) ?></p>
            <div class="acciones">
                <a href="Agregar_alumno.php" class="boton-guardar">Volver a intentar</a>
                <a href="../tabla_usuarios/pagina_tabla_usuarios.php" class="boton-volver">Ir a la Tabla de Usuarios</a>
            </div>
            <?php endif; ?>
        </section>
    </main>
<footer class="pie-comun">Todos los derechos reservados — Grupo Medusa</footer>
</body>
</html>
