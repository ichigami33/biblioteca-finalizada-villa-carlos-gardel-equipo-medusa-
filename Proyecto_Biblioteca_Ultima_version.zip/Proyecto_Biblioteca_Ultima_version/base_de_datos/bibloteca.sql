-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-09-2026 a las 01:04:32
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bibloteca`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `librost`
--

CREATE TABLE `librost` (
  `isbn` int(13) NOT NULL COMMENT '"dni" del libro',
  `tema` int(2) NOT NULL,
  `autor` varchar(20) NOT NULL,
  `stock` int(2) NOT NULL,
  `nombrel` varchar(30) DEFAULT NULL,
  `editorial` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `librost`
--

INSERT INTO `librost` (`isbn`, `tema`, `autor`, `stock`, `nombrel`, `editorial`) VALUES
(112312, 8, 'nico', 99, 'principe', 'nico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sansl`
--

CREATE TABLE `sansl` (
  `id` int(3) NOT NULL COMMENT 'id del alumno que se llevo la sansion',
  `sans1` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sansl`
--

INSERT INTO `sansl` (`id`, `sans1`) VALUES
(1, '1'),
(1, '2'),
(1, 'otra sancion mas por que si');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temast`
--

CREATE TABLE `temast` (
  `tema` int(2) NOT NULL,
  `tematare` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `temast`
--

INSERT INTO `temast` (`tema`, `tematare`) VALUES
(1, 'Fantasia'),
(2, 'Ciencia Ficcion'),
(3, 'Policiaco'),
(4, 'Romance'),
(5, 'Historia'),
(6, 'Matematica'),
(7, 'Geometria'),
(8, 'Terror');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(3) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `contraseña` varchar(500) NOT NULL,
  `tel` int(10) NOT NULL,
  `mail` varchar(60) NOT NULL,
  `sans` int(2) NOT NULL,
  `libros` int(3) NOT NULL COMMENT 'isbns de los libros prestados',
  `curso_actual` varchar(30) DEFAULT NULL,
  `rango` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contraseña`, `tel`, `mail`, `sans`, `libros`, `curso_actual`, `rango`) VALUES
(1, 'nico', '$2y$10$9qZm9N2UYz9NRUzcMvrmG.MtsUL4urRoZ3qRuGGvzhl94r1FhMJMC', 891238912, 'nico@gmail.com', 0, 0, '1°A', 'Directivo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `librost`
--
ALTER TABLE `librost`
  ADD PRIMARY KEY (`isbn`);

--
-- Indices de la tabla `temast`
--
ALTER TABLE `temast`
  ADD PRIMARY KEY (`tema`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`),
  ADD UNIQUE KEY `tel` (`tel`),
  ADD UNIQUE KEY `nombreusuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
