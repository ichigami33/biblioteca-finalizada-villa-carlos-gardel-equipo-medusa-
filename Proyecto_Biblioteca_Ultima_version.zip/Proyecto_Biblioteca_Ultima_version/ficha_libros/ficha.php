<?php
require_once __DIR__ . '/../Inicio_Sesion/sesion.php';
$raiz = '../';
exigir_sesion($raiz);
$urlBiblioteca = '../Biblioteca_Comun/Archivos_Biblioteca_Comun/Pagina_Biblioteca_Comun.php';
$valorIsbn = $_GET['isbn'] ?? null;
$isbn = is_string($valorIsbn) && ctype_digit($valorIsbn) && (int)$valorIsbn > 0 && (int)$valorIsbn <= 2147483647 ? (int)$valorIsbn : 0;
if (!$isbn) mostrar_error($raiz, 'ISBN no válido', 'Abrí el libro desde el catálogo para consultar su ficha.', [['Volver a la biblioteca', $urlBiblioteca]], 400);
if (empty($_SESSION['stock_csrf'])) $_SESSION['stock_csrf'] = bin2hex(random_bytes(32));
$stockActualizado = !empty($_SESSION['stock_actualizado'][$isbn]);
unset($_SESSION['stock_actualizado'][$isbn]);
$error = '';
try {
    require_once __DIR__ . '/conexion.php';
    $stmt = $conexion->prepare('SELECT isbn, tema, autor, stock, nombrel, editorial FROM librost WHERE isbn = ?');
    $stmt->bind_param('i', $isbn);
    $stmt->execute();
    $libro = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$libro) mostrar_error($raiz, 'Libro no encontrado', 'No hay ningún libro registrado con ese ISBN.', [['Volver a la biblioteca', $urlBiblioteca]], 404);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? null;
        $cantidad = $_POST['nueva_cantidad'] ?? null;
        if (!es_admin()) {
            http_response_code(403);
            $error = 'Tu rango no permite modificar el stock.';
        } elseif (!is_string($token) || !hash_equals($_SESSION['stock_csrf'], $token)) {
            http_response_code(403);
            $error = 'El formulario venció. Actualizá la ficha y volvé a intentar.';
        } elseif (!is_string($cantidad) || !ctype_digit($cantidad) || (int)$cantidad > 99) {
            http_response_code(400);
            $error = 'El stock debe ser un número entero entre 0 y 99.';
        } else {
            $stock = (int)$cantidad;
            $stmt = $conexion->prepare('UPDATE librost SET stock = ? WHERE isbn = ?');
            $stmt->bind_param('ii', $stock, $isbn);
            $stmt->execute();
            $stmt->close();
            $_SESSION['stock_actualizado'][$isbn] = true;
            header('Location: ficha.php?isbn=' . $isbn);
            exit;
        }
    }
    $conexion->close();
} catch (Throwable $e) {
    mostrar_error($raiz, 'Error al consultar el libro', 'No se pudo consultar o actualizar el libro. Verificá que la base de datos esté disponible e intentá nuevamente.', [['Volver a intentar', 'ficha.php?isbn=' . $isbn], ['Volver a la biblioteca', $urlBiblioteca]], 500);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($libro['nombrel']) ?> | Biblioteca Común</title>
    <link rel="stylesheet" href="styles.css?v=<?= (int)filemtime(__DIR__ . '/styles.css') ?>">
    <?php estilo_sesion($raiz); ?>
</head>
<body>
<header id="header">
    <a class="marca" href="<?= h($urlBiblioteca) ?>">
        <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5.5C4 4.7 4.7 4 5.5 4H11v15H5.5C4.7 19 4 18.3 4 17.5v-12z"/><path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H13v15h5.5c.8 0 1.5-.7 1.5-1.5v-12z"/></svg>
        <span>Biblioteca Virtual</span>
    </a>
        <span class="contexto-header" aria-label="Sección actual">Ficha de libro</span>
    <?php mostrar_sesion($raiz); ?>
</header>
<div class="sub-header"><span>Biblioteca Virtual</span><span class="separador">•</span><strong>Villa Gardel</strong></div>
<main id="inicio">
    <section class="recuadro_al_centro">
        <div class="carnet">
            <div class="titulo_carnet"><h1>INFORMACIÓN DEL LIBRO</h1></div>
            <?php if ($error !== ''): ?><p class="aviso-carnet" role="alert"><?= h($error) ?></p><?php endif; ?>
            <?php if ($stockActualizado): ?><p class="aviso-exito" role="status">El stock se actualizó correctamente.</p><?php endif; ?>
            <div class="contenido_carnet"><div class="datos_estudiante">
                <div class="dato"><span class="etiqueta">NOMBRE</span><strong><?= h($libro['nombrel']) ?></strong></div>
                <div class="dato"><span class="etiqueta">ISBN</span><strong><?= (int)$libro['isbn'] ?></strong></div>
                <div class="dato"><span class="etiqueta">AUTOR</span><strong><?= h($libro['autor']) ?></strong></div>
                <div class="dato"><span class="etiqueta">EDITORIAL</span><strong><?= h($libro['editorial']) ?></strong></div>
            </div></div>
            <div class="titulo_seccion">
                <h2>Stock actual: <?= (int)$libro['stock'] ?></h2>
                <?php if (es_admin()): ?>
                <form method="post" class="numeros">
                    <input type="hidden" name="csrf" value="<?= h($_SESSION['stock_csrf']) ?>">
                    <label for="nueva_cantidad">Nueva cantidad</label>
                    <input type="number" id="nueva_cantidad" name="nueva_cantidad" min="0" max="99" value="<?= (int)$libro['stock'] ?>" required>
                    <button type="submit" class="añadir">Modificar stock</button>
                </form>
                <?php endif; ?>
            </div>
            <p class="ficha-volver"><a href="<?= h($urlBiblioteca) ?>">← Volver a la biblioteca</a></p>
        </div>
    </section>
</main>
<footer><div class="parte_de_abajo">Todos los derechos reservados — Grupo Medusa</div></footer>
</body>
</html>
